package com.viexplorer.recipehelper.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.gui.screen.ingame.BrewingStandScreen;
import net.minecraft.client.gui.screen.ingame.EnchantmentScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.SmithingScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;

public class VIRecipeHelperClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof BrewingStandScreen) {
                ScreenEvents.remove(screen);
                BrewingPanel.reset();

                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) ->
                        BrewingPanel.render(ctx, client.textRenderer, s.width, s.height, mouseX, mouseY));

                ScreenMouseEvents.allowMouseClick(screen).register((s, mouseX, mouseY, button) -> {
                    BrewingPanel.click(s.width, s.height, mouseX, mouseY);
                    return true;
                });

                ScreenMouseEvents.allowMouseScroll(screen).register((s, mouseX, mouseY, horizontal, vertical) ->
                        !BrewingPanel.scroll(s.width, s.height, mouseX, mouseY, vertical));
            } else if (screen instanceof EnchantmentScreen) {
                ScreenEvents.remove(screen);
                EnchantPanel.reset();

                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) -> {
                    ItemStack stack = ((EnchantmentScreen) s).getScreenHandler().getSlot(0).getStack();
                    EnchantPanel.render(ctx, client.textRenderer, client, stack, s.width, s.height, mouseX, mouseY);
                });

                ScreenMouseEvents.allowMouseScroll(screen).register((s, mouseX, mouseY, horizontal, vertical) ->
                        !EnchantPanel.scroll(s.width, s.height, mouseX, mouseY, vertical));
            } else if (screen instanceof SmithingScreen) {
                ScreenEvents.remove(screen);
                SmithingPanel.reset();

                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) -> {
                    ScreenHandler handler = ((HandledScreen<?>) s).getScreenHandler();
                    SmithingPanel.render(ctx, client.textRenderer, client, handler, s.width, s.height);
                });

                ScreenMouseEvents.allowMouseClick(screen).register((s, mouseX, mouseY, button) -> {
                    SmithingPanel.press(s.width, s.height, mouseX, mouseY);
                    return true;
                });
            }
        });
    }
}
